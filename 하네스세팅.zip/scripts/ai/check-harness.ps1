#Requires -Version 7.0
<#
.SYNOPSIS
Read-only personal harness checks; no external modules required.
.DESCRIPTION
Checks AGENTS line count, required skill metadata and local Markdown references.
Not a complete YAML/Markdown validator, or a Unity runtime check.
Exit codes: 0 = passed, 1 = validation failed, 2 = could not run/read input.
.PARAMETER ProjectRoot
Unity project root. Defaults to two levels above this script, independent of cwd.
#>
[CmdletBinding()]
param([string]$ProjectRoot = (Join-Path $PSScriptRoot '../..'))

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$issues = [System.Collections.Generic.List[string]]::new()
$documents = [System.Collections.Generic.Dictionary[string, string]]::new()
$skillCount = 0
$referenceCount = 0
$agentLineCount = 0
$utf8 = [System.Text.UTF8Encoding]::new($false, $true)

function Add-Issue([string]$Path, [string]$Reason) {
    $displayPath = [System.IO.Path]::GetRelativePath($root, $Path)
    $issues.Add(('{0}: {1}' -f $displayPath, $Reason))
}

function Read-Document([string]$Path) {
    return [System.IO.File]::ReadAllText($Path, $utf8)
}

function Remove-CodeBlocks([string]$Text) {
    $fence = $null
    $result = [System.Collections.Generic.List[string]]::new()
    foreach ($line in [regex]::Split($Text, '\r?\n')) {
        if ($null -eq $fence) {
            $match = [regex]::Match($line, '^\s{0,3}(?<fence>\x60{3,}|~{3,})')
            if ($match.Success) {
                $fence = $match.Groups['fence'].Value
                $result.Add('')
                continue
            }
        }
        else {
            $closingPattern = '^\s{0,3}' + [regex]::Escape($fence.Substring(0, 1)) + '{' + $fence.Length + ',}\s*$'
            if ($line -match $closingPattern) { $fence = $null }
            $result.Add('')
            continue
        }
        $result.Add($line)
    }
    return $result -join [char]10
}

function Check-Reference([string]$Document, [string]$Target, [string]$BasePath) {
    $targetPath = $Target.Trim().Trim('<', '>')
    if ($targetPath -match '^(#|//)' -or
        ($targetPath -match '^[a-zA-Z][a-zA-Z0-9+.-]*:' -and $targetPath -notmatch '^[a-zA-Z]:[\\/]') -or
        $targetPath -match '[<>]|\$\{|\{\{') { return }
    $targetPath = ($targetPath -split '#', 2)[0]
    if ([string]::IsNullOrWhiteSpace($targetPath)) { return }
    $targetPath = [System.Uri]::UnescapeDataString($targetPath)
    $resolved = if ([System.IO.Path]::IsPathRooted($targetPath)) {
        [System.IO.Path]::GetFullPath($targetPath)
    }
    else {
        [System.IO.Path]::GetFullPath((Join-Path $BasePath $targetPath))
    }
    $script:referenceCount++
    if (-not (Test-Path -LiteralPath $resolved)) {
        Add-Issue $Document "missing local reference: $Target"
    }
}

try {
    $root = (Resolve-Path -LiteralPath $ProjectRoot).ProviderPath
    if (-not (Test-Path -LiteralPath $root -PathType Container)) {
        throw 'ProjectRoot must be a directory.'
    }
    $agentPath = Join-Path $root 'AGENTS.md'
    if (-not (Test-Path -LiteralPath $agentPath -PathType Leaf)) {
        Add-Issue $agentPath 'required AGENTS.md is missing'
    }
    else {
        $agentText = Read-Document $agentPath
        $documents.Add($agentPath, $agentText)
        $agentLineCount = [System.IO.File]::ReadAllLines($agentPath, $utf8).Length
        if ($agentLineCount -gt 250) {
            Add-Issue $agentPath "line count $agentLineCount exceeds 250"
        }
    }

    # Empty placeholders are intentionally unconfigured. Do not parse config.toml.
    foreach ($folder in @('docs/ai', '.agents/skills')) {
        $folderPath = Join-Path $root $folder
        if (-not (Test-Path -LiteralPath $folderPath -PathType Container)) { continue }
        foreach ($file in Get-ChildItem -LiteralPath $folderPath -Filter '*.md' -File -Recurse -Force) {
            $text = Read-Document $file.FullName
            if (-not [string]::IsNullOrWhiteSpace($text)) {
                $documents.Add($file.FullName, $text)
            }
        }
    }

    $skillsRoot = Join-Path $root '.agents/skills'
    if (Test-Path -LiteralPath $skillsRoot -PathType Container) {
        foreach ($folder in Get-ChildItem -LiteralPath $skillsRoot -Directory -Force) {
            $skillPath = Join-Path $folder.FullName 'SKILL.md'
            if (-not (Test-Path -LiteralPath $skillPath -PathType Leaf)) { continue }
            if (-not $documents.ContainsKey($skillPath)) { continue }
            $text = $documents[$skillPath]
            $skillCount++
            $header = [regex]::Match($text, '\A---\r?\n(?<body>.*?)\r?\n---(?:\r?\n|\z)', 'Singleline')
            if (-not $header.Success) {
                Add-Issue $skillPath 'missing frontmatter delimiters'
                continue
            }
            $body = $header.Groups['body'].Value
            foreach ($field in @('name', 'description')) {
                $fieldPattern = '(?m)^' + $field + ':[ \t]*(?<value>[^\r\n]*)'
                $values = [regex]::Matches($body, $fieldPattern)
                if ($values.Count -ne 1) {
                    Add-Issue $skillPath "required field '$field' must appear exactly once"
                    continue
                }
                $value = $values[0].Groups['value'].Value.Trim()
                $quotedValue = $false
                if ($value.Length -ge 2 -and
                    (($value.StartsWith('"') -and $value.EndsWith('"')) -or
                     ($value.StartsWith("'") -and $value.EndsWith("'")))) {
                    $quotedValue = $true
                    $value = $value.Substring(1, $value.Length - 2).Trim()
                }
                if ($field -eq 'description' -and $value -match '^[|>][+-]?$') {
                    $remaining = $body.Substring($values[0].Index + $values[0].Length)
                    $value = [regex]::Match($remaining, '\A\r?\n(?<lines>(?:[ \t]+[^\r\n]*(?:\r?\n|\z))+)').Groups['lines'].Value.Trim()
                }
                if ([string]::IsNullOrWhiteSpace($value) -or (-not $quotedValue -and $value -match '^(null|~)$|^#')) {
                    Add-Issue $skillPath "required field '$field' is empty"
                }
                elseif ($field -eq 'name' -and
                    ($value -cne $folder.Name -or $value -notmatch '^[a-z0-9]+(?:-[a-z0-9]+)*$' -or $value.Length -ge 64)) {
                    Add-Issue $skillPath "name must match folder '$($folder.Name)' and use fewer than 64 lowercase letters, digits or hyphens"
                }
            }
        }
    }

    $inlineCodePattern = [string][char]96 + '[^' + [char]96 + '\r\n]*' + [char]96
    # Literal inline/image links and reference destinations; fenced examples excluded.
    $linkPattern = '\[[^\]\r\n]*\]\(\s*(?<target><[^>\r\n]+>|(?:\\.|[^\s()])+(?:\((?:\\.|[^()])*\)(?:\\.|[^\s()])*)*)'
    $referencePattern = '(?m)^\s{0,3}\[[^\]\r\n]+\]:\s*(?<target><[^>\r\n]+>|\S+)'
    foreach ($entry in $documents.GetEnumerator() | Sort-Object Key) {
        $prose = Remove-CodeBlocks $entry.Value
        $prose = [regex]::Replace($prose, $inlineCodePattern, '')
        foreach ($pattern in @($linkPattern, $referencePattern)) {
            foreach ($match in [regex]::Matches($prose, $pattern)) {
                Check-Reference $entry.Key $match.Groups['target'].Value (Split-Path $entry.Key -Parent)
            }
        }
    }

    # Backtick paths in AGENTS tables are rooted at the Unity project.
    if ($documents.ContainsKey($agentPath)) {
        $codePathPattern = [string][char]96 + '(?<target>[^' + [char]96 + ']+)' + [char]96
        foreach ($line in [regex]::Split((Remove-CodeBlocks $documents[$agentPath]), '\r?\n')) {
            if ($line -notmatch '^\s*\|') { continue }
            foreach ($match in [regex]::Matches($line, $codePathPattern)) {
                Check-Reference $agentPath $match.Groups['target'].Value $root
            }
        }
    }

    if ($issues.Count -gt 0) {
        foreach ($issue in $issues) { Write-Output "FAIL $issue" }
        Write-Output "FAIL harness: $($issues.Count) issue(s)"
        exit 1
    }
    Write-Output "PASS harness: AGENTS $agentLineCount/250 lines; $skillCount skills; $referenceCount local references"
    Write-Output 'Checked required metadata and file existence only; not full YAML or runtime behavior.'
    exit 0
}
catch {
    Write-Output "ERROR harness: $($_.Exception.Message)"
    exit 2
}
