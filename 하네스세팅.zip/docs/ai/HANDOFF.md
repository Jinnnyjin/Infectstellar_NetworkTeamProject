# Infectstellar 개인 Codex 하네스 인수인계

최종 확인일: 2026-10-05 (Asia/Seoul)

## 1. 목적과 다음 작업

사용자는 Unity 팀 프로젝트에서 개인용 Codex 작업 환경을 구성하고 있다. 처음에는 폴더와 빈 파일만 생성했고, 앞으로 실제 프로젝트를 조사하고 사용자와 논의하며 필요한 내용을 채우려 한다.

최초 인수인계 이후 AGENTS.md, 다섯 스킬, PROJECT.md, UNITY.md를 구성했다. 계획 관리 기준, 기존 Unity MCP 사용 기준과 읽기 전용 하네스 검사 자동화의 상세 단계·결정·검증 결과는 [이전 구성 작업 기록](plans/2026-10-05-harness-planning-validation.md)에 둔다. 이후 사용자 요청으로 이전하네스세팅.zip에서 추린 세 가지를 기존 스킬에 반영했다: 실제 컴파일 근거 확인, 원인 오류와 중복·연쇄 오류 구분, 최종 수정본 기준의 검증 결과 유지. 새 파일 없이 AGENTS.md와 UNITY.md의 관련 기준도 맞췄으며 Context7·외부 라이브러리 절차는 이번 반영에 포함하지 않았다.

AGENTS.md에는 프로젝트 범위, 질문·실행 구분, 기존 변경 보호, 문서·스킬 사용 조건, 작업·검증·완료 보고 기준, 하네스 유지와 250줄 이하 관리 규칙이 있다. 구현·수정 요청 중 관련 PROJECT.md 설명이 달라지거나 사용자 변경과 문서의 불일치를 발견하면 별도 갱신 요청 없이 바로잡는다. 현재 구현은 실제 파일에서 확인하며 매번 전체 프로젝트를 조사하지 않는다. 필요한 인수인계 상태도 함께 유지한다.

질문·설명·검토 요청에서는 여전히 읽기 전용이다. 새로운 공통 정책·스킬·Unity 작업 규칙은 명시적인 반영 요청에 따른다. Unity 문제나 구체적인 위험에서 재발 방지 규칙이 필요하면 Codex가 사용자 요청 없이 근거·적용 범위·확인 방법과 문구를 제안한다. 사용자가 먼저 발견하거나 작성할 필요는 없다. COMMANDS.md는 사용자 선택으로 비워두며 별도 작성 요청 전까지 갱신하지 않는다. 실제 담당 영역·코드 컨벤션·검증 명령은 미확정이므로 다음 작업도 사용자 요청 범위부터 진행한다.

다음 채팅은 이 문서를 읽고 실제 파일 상태를 재확인한 뒤, 사용자가 요청하는 항목부터 진행한다. 전체 설정을 임의로 한꺼번에 채우거나 설치하지 않는다. 이 문서는 작성 시점의 상태이며 이후 사용자가 별도로 변경했을 수 있다.

## 2. 반드시 지킬 사용자 작업 방식

- 질문, 설명 요청, 검토 요청에는 답변과 필요한 읽기 전용 확인만 수행한다.
- “먼저 HANDOFF만 쓰면 안 돼?”, “이렇게 할 수 있어?” 같은 가능 여부 질문을 변경 작업 승인으로 해석하지 않는다.
- “작성해줘”, “수정해줘”, “설치해줘”처럼 명시적인 실행 요청이 있을 때 해당 범위의 작업을 수행한다.
- 실행 의도가 불분명하면 변경 전에 확인한다.
- 용어를 초보자가 이해할 수 있게 설명한다. 공식 지원 구조, 공개 사례, AI의 자체 제안을 구분한다.
- 기존 사용자 변경을 되돌리거나 커밋·푸시하지 않는다. 설치·MCP 등록·Pipeline 변경도 별도 요청 없이 수행하지 않는다.
- 새 채팅이라는 이유로 이 인수인계 작업을 다시 시작하거나 모든 파일을 다시 생성하지 않는다.

위 질문/실행 구분은 현재 프로젝트 AGENTS.md에도 이미 작성되어 있다. 이전 채팅의 “모든 파일이 비어 있다”는 설명은 더 이상 현재 상태와 일치하지 않는다.

## 3. 프로젝트 위치와 환경

- Unity 프로젝트 / 현재 작업 폴더:
  `C:\Users\tlawl\OneDrive\Desktop\UnityStudy\UnityProjects\Infectstellar_NetworkTeamProject\Infectstellar`
- Git 저장소 최상위:
  `C:\Users\tlawl\OneDrive\Desktop\UnityStudy\UnityProjects\Infectstellar_NetworkTeamProject`
- Git 저장소 최상위와 Unity 프로젝트 루트는 다르다. Unity 프로젝트는 저장소 안의 Infectstellar 하위 폴더이다.
- OS: Windows. 이전 확인은 PowerShell에서 수행했다.
- ProjectSettings/ProjectVersion.txt: Unity `6000.3.6f1`, revision `bbb010bdb8a3`.
- Assets의 현재 최상위 폴더: Import, KHJ, Plugins, Resources, Scenes, Settings, TextMesh Pro, TutorialInfo.
- 이번 PROJECT.md 작성에서는 Assets의 실제 파일을 조사했다. C#은 Readme와 ReadmeEditor 두 개이며 게임용 코드·프리팹·asmdef는 검색되지 않았다. SampleScene, 입력 액션과 렌더링 설정 위치를 PROJECT.md에 기록했다. 게임 기획·네트워크 구현·실행 결과·테스트/빌드 명령은 미확정이다.

## 4. 현재 구성 트리

아래 경로는 Unity 프로젝트 루트 기준이다.

```text
Infectstellar/
├── AGENTS.md
├── .codex/
│   ├── config.toml
│   └── agents/
│       └── .gitkeep
├── .agents/
│   └── skills/
│       ├── bug-fix/SKILL.md
│       ├── code-review/SKILL.md
│       ├── unity-validation/SKILL.md
│       ├── git-workflow/SKILL.md
│       └── self-update/SKILL.md
├── docs/
│   └── ai/
│       ├── PROJECT.md
│       ├── COMMANDS.md
│       ├── UNITY.md
│       ├── PLANS.md
│       ├── HANDOFF.md
│       ├── plans/
│       │   ├── .gitkeep
│       │   └── 2026-10-05-harness-planning-validation.md
│       └── decisions/.gitkeep
└── scripts/
    └── ai/
        ├── .gitkeep
        └── check-harness.ps1
```

현재 구성은 총 18개 파일이다. AGENTS.md, PROJECT.md, UNITY.md, PLANS.md, 이 HANDOFF.md, 다섯 SKILL.md, 작업 계획 한 개와 검사 스크립트에 내용이 있고, 나머지 6개 파일은 비어 있다.

## 5. 각 경로의 역할과 상태

| 경로 | 역할 | 현재 상태 / 주의점 |
|---|---|---|
| AGENTS.md | Codex가 읽는 프로젝트 공통 작업 지침 | 개인용 작업 범위·변경 보호·자료 사용 조건·작업 및 검증 기준·하네스 갱신·250줄 이하 유지 규칙 작성됨. 프로젝트별 코드 컨벤션과 실제 검증 명령은 미확정 |
| .codex/ | 프로젝트 전용 Codex 설정 보관 위치 | 사용자 전체 설정과 구분되는 프로젝트 범위 |
| .codex/config.toml | 모델·권한·MCP 연결 등 지원되는 Codex 설정을 TOML 문법으로 작성 | 빈 파일 유지. 이 프로젝트 설정을 추가하지 않아도 현재 MCP 상태 조회는 성공함. 기존 연결·모델·권한 설정을 변경하지 않음 |
| .codex/agents/ | 프로젝트별 커스텀 서브에이전트 역할 설정 보관 | .gitkeep만 있음. 커스텀 역할은 정의되지 않음 |
| .agents/skills/ | 프로젝트용 반복 작업 절차를 담는 공식 스킬 발견 위치 | 다섯 스킬의 name·description과 작업 절차 작성됨. 필요한 작업에서만 참고 |
| bug-fix/SKILL.md | 증상·원인 조사 → 요청한 수정 → 관련 검증 | 분석 요청은 읽기 전용. 컴파일 오류는 원인·중복·연쇄 오류를 구분하고 원인 수정 후 남은 오류를 재확인 |
| code-review/SKILL.md | 오류·회귀 위험·검증 근거를 읽기 전용으로 검토 | 근거·발생 조건·위치·영향 보고. 리뷰만으로 코드·문서·Git 상태 변경 금지 |
| unity-validation/SKILL.md | 변경에 맞는 문서·컴파일·테스트·실행 확인 선택 | 실제 컴파일 근거와 로그 범위 확인. 검증 후 수정하면 영향받은 결과만 재확인. 검증만 요청받으면 소스 수정하지 않음 |
| git-workflow/SKILL.md | Git 상태 확인과 명시적으로 요청한 Git 작업 | 기존 변경·개인 exclude 보호. 커밋 요청만으로 푸시·PR 생성하지 않음 |
| self-update/SKILL.md | 확인된 지식 선별과 갱신 | 관련 프로젝트 설명·인수인계·조건에 맞는 작업 계획 자동 갱신, Unity 재발 방지 규칙 선제 제안. 규칙 변경은 요청 후 반영 |
| docs/ | 일반 프로젝트 문서의 상위 폴더 | 이름 자체에 Codex 기능 없음 |
| docs/ai/ | AI 작업용 지식과 작업 기록을 모으는 프로젝트별 문서 구분 | 이름 자체에 자동 로딩 기능 없음 |
| PROJECT.md | 프로젝트 구조·주요 시스템 설명 | 현재 자산·씬·코드 위치와 미확인 사항 작성됨. 구현·수정 중 관련 실제 파일과 대조해 갱신 |
| COMMANDS.md | 빌드·테스트·검증 명령과 실행 조건 | 사용자 선택으로 빈 파일 유지. 별도 작성 요청 전까지 자동 갱신 제외 |
| UNITY.md | Unity 작업 시 필요한 주의사항 | 기존 자산·직렬화·씬 기준에 MCP 대상·준비·컴파일·Play 상태 확인과 연결 실패 대응을 추가함. 게임 시스템별 규칙은 미확정 |
| PLANS.md | 개별 작업 계획을 작성·관리하는 기준 | 여러 단계의 구현·수정에서 계획 자동 관리. 작은 수정 생략, 단계 완료·중단·범위 변경 시 갱신. 질문·논의에서는 파일 변경 금지 |
| plans/ | 작업별 계획과 진행 기록 | .gitkeep과 이번 하네스 구성 작업 기록 한 개. 주요 결정은 계획에 우선 기록 |
| HANDOFF.md | 현재 상태·남은 작업·사용자 의도 인수인계 | 이 문서. 자동 발견을 가정하지 말고 새 채팅에서 읽도록 요청 |
| decisions/ | 기술·설계 선택과 그 이유 기록 | .gitkeep만 있음 |
| scripts/ | 실행 가능한 자동화 스크립트 보관 | 필수 폴더가 아님 |
| scripts/ai/ | AI가 사용할 검증/자동화 스크립트 보관 | .gitkeep과 check-harness.ps1. 하네스 작성·수정 마무리에서만 검사하며 백그라운드 감시하지 않음 |
| scripts/ai/check-harness.ps1 | 외부 모듈 없는 읽기 전용 PowerShell 7 검사 | AGENTS 줄 수·내용 있는 스킬 필수 메타데이터·로컬 Markdown 참조·AGENTS 자료표 경로 검사. 종료 코드 0 통과 / 1 검사 실패 / 2 실행·읽기 오류 |
| .gitkeep 4개 | Git이 빈 폴더 자체를 추적하지 않으므로 파일을 두어 구조 보존 | 특별한 실행 기능 없음. 현재 이 경로들은 개인 exclude 대상이라 팀 저장소에는 올라가지 않음 |

스킬은 특정 작업의 매뉴얼이며 모델 재훈련이 아니다. 커스텀 서브에이전트는 별도 작업자 역할 설정이다. 보조 문서·스크립트는 이름만으로 자동 사용되지 않으며, 후속 작성 때 AGENTS.md나 스킬에서 언제 읽고 실행할지 연결해야 한다. 모든 빈 자리를 반드시 채울 필요는 없다.

현재 AGENTS.md는 92줄이며 COMMANDS.md는 비어 있다. 검사 자동화 구성 시 PowerShell 검사와 임시 오류 사례로 필수 메타데이터·참조·종료 코드·읽기 전용 동작을 확인했다. 이전 quick_validate.py는 PyYAML이 없어 실행하지 못했으므로 추가 설치 없이 필수 검사만 구현했다. 전체 YAML 문법이나 스킬의 실제 자동 선택·행동 검증은 아니다. 세 가지 스킬 보강 후 하네스 검사는 통과했다(AGENTS 92/250줄, 스킬 5개, 로컬 참조 38개). 읽기 전용 분석·문서 작업·재수정 시 절차의 일관성을 검토했고, COMMANDS.md·Codex 설정의 빈 상태와 기존 패키지 변경을 보존했다. 실제 Unity 컴파일·게임 실행·테스트·씬 변경은 이번 검증에 포함하지 않는다.

## 6. 구성 선정 근거와 이전 설명의 정정

- 사용자의 원래 의도는 “보편적으로 많이 사용하는 하네스 구성”을 선택식 질문으로 정하는 것이었다.
- 이전 AI는 공식 경로에 자체 제안한 문서·스킬 구성을 더해 후보를 제시했고, 사용자가 선택한 항목을 생성했다.
- 여러 인기 저장소의 실제 사용 빈도를 조사하여 공통 구성을 선정한 것은 아니다. 전체 트리를 “보편적인 표준 템플릿”으로 소개하면 안 된다.
- AGENTS.md, .codex/config.toml, .agents/skills/*/SKILL.md, .codex/agents/는 공식 지원 구조이다. 공식 지원이 곧 널리 사용됨을 증명하지는 않는다.
- 기존 네 스킬 이름과 조합, docs/ai의 파일 이름/분리 방식, scripts/ai는 이전 AI의 프로젝트용 제안이다. self-update는 사용자가 검토한 지식 갱신 절차를 Codex용으로 추가 요청한 스킬이다.
- 이후 AGENTS.md 구성 시에는 OpenAI 공식 지침 문서와 지침 간소화 안내, Ruff와 .NET SDK의 AGENTS.md를 비교했다. 필요한 자료의 조건부 참조, 실제 근거 확인, 구체적인 검증 기준을 참고해 개인 프로젝트에 맞게 작성했으며, 공개 저장소의 명령·팀 정책은 복사하지 않았다. 250줄 상한은 사용자와 정한 관리 기준이며 공식 제한이 아니다.
- 계획·상태·검증·결정 기록은 OpenAI 공개 장기 작업 사례에 유사한 목적의 문서가 있다. 해당 사례는 사용자가 근거를 물은 뒤 추가 확인한 것이며, 처음부터 이 전체 트리의 조사 근거였던 것은 아니다.
- 스킬 평가용 evals/skills는 사용자가 보류했다.
- scripts/ai에는 사용자와 확정한 반복 하네스 검사만 추가했다. 게임 검증 자동화나 예약 실행은 구성하지 않았다.

참고 자료:
- 지침: https://learn.chatgpt.com/docs/agent-configuration/agents-md
- 설정: https://learn.chatgpt.com/docs/config-file/config-basic
- 스킬: https://learn.chatgpt.com/docs/build-skills
- 서브에이전트: https://learn.chatgpt.com/docs/agent-configuration/subagents
- 공개 장기 작업 사례: https://developers.openai.com/blog/run-long-horizon-tasks-with-codex
- PLANS.md 사례: https://developers.openai.com/cookbook/articles/codex_exec_plans (아카이브된 예시이며 필수 표준이 아님)
- 지침 간소화 안내: https://developers.openai.com/blog/rethinking-skills-and-prompts-for-gpt-6-astra
- 공개 저장소 사례: https://github.com/astral-sh/ruff/blob/main/AGENTS.md
- 공개 저장소 사례: https://github.com/dotnet/sdk/blob/main/AGENTS.md

## 7. 개인 Git 제외 설정

사용자는 개인 AI 설정이 팀원에게 공유되거나 팀원의 Git 제외 규칙에 영향을 주는 것을 원하지 않는다.

현재 설정 위치는 **Git 저장소 최상위의 `.git/info/exclude`**이다. Unity 프로젝트 안의 .gitignore도, 부모의 공유 .gitignore도 아니다.

```gitignore
/Infectstellar/AGENTS.md
/Infectstellar/.codex/
/Infectstellar/.agents/
/Infectstellar/[Dd]ocs/
/Infectstellar/[Ss]cripts/ai/
```

- 위 경로는 Git 저장소 최상위 기준이다.
- docs/ai뿐 아니라 프로젝트의 docs/Docs 전체를 제외하는 선택이다.
- .git/info/exclude는 이 로컬 저장소에만 적용되며 커밋되지 않는다. 새 clone에는 자동 전달되지 않는다.
- 두 공유 .gitignore에서 개인 규칙은 제거되었으며 이번 확인에서도 HEAD 대비 차이가 없다.
- git check-ignore -v로 대표 파일들이 .git/info/exclude에 의해 제외됨을 재확인했다. 이전 검증에서는 구성 파일 15개 모두 확인했다.
- git ls-files 결과 AI 경로는 추적되지 않는다. 이 HANDOFF.md도 개인 제외 대상이다. 추가한 self-update 스킬도 기존 .agents/ 제외 규칙의 적용 대상이다.
- 제외는 파일을 삭제하지 않는다. 일반 git add에서 빠지지만 git add -f 같은 강제 추가는 가능하므로 “절대 업로드 불가능”하다고 설명하지 않는다.
- 이미 추적 중인 파일의 변경은 ignore/exclude로 숨겨지지 않는다. 패키지 공용 파일을 제외하거나 추적 해제하는 작업을 임의로 하지 않는다.

## 8. Unity CLI / MCP / Pipeline 현재 상태

이전 채팅에서는 사용자가 다음 연결 흐름을 질문했다.

```powershell
unity mcp configure codex
unity pipeline install
unity status
```

역할:
- Unity CLI: AI 자체가 아니라 명령 전달/실행 도구이다.
- MCP configure: Codex 쪽 서버 연결 등록이다. Pipeline 설치와 별개이다.
- Pipeline: Unity Editor 안에서 외부 명령을 수신·실행할 패키지이다.
- status: CLI와 실행 중인 Editor 연결 상태 확인이며, Codex의 MCP 전체 연결 성공을 단독으로 증명하지 않는다.
- 프로젝트 전용 Codex 연결 설정에는 `unity mcp configure codex --local` 방식이 있다. 실제 등록은 요청과 설치 버전의 도움말을 확인한 뒤 수행한다.

**이번 확인에서 발견한 최신 상태:**
- Packages/manifest.json에 `com.unity.pipeline: 0.8.0-exp.1`이 등록되어 있다.
- Packages/packages-lock.json에도 동일 버전의 Pipeline 항목이 있다.
- 잠금 파일에는 newtonsoft-json 3.2.2 추가와 mono-cecil 의존성 depth 변경도 있다. 패키지 변경을 처리할 때 Pipeline 한 줄만 보고 판단하지 않는다.
- 위 두 파일은 Git 추적 대상이며 현재 커밋되지 않은 수정 상태다.
- 이 채팅의 도구 작업은 Pipeline을 설치하지 않았다. 사용자가 별도로 진행했을 수 있다. “Pipeline이 아직 없다”는 이전 답변은 현재 상태와 맞지 않는다.
- manifest/lock 등록만으로 다운로드·컴파일·실행 성공을 단정하지 않는다. 2026-10-05 18:48 +09:00 MCP editor_status 조회에서는 현재 Infectstellar 프로젝트, Unity 6000.3.6f1, ready, compiling=false, domainReloadInProgress=false, playMode=stopped를 확인했다. 상태 조회만 수행했으며 게임 동작·테스트 통과는 확인하지 않았다.
- 현재 Codex 터미널에서 Get-Command unity는 결과가 없었다. 사용자 .local/bin에서도 unity 파일을 찾지 못했다.
- 이것만으로 컴퓨터 전체에 CLI가 없다고 단정하지 않는다. 다른 설치 위치나 터미널 PATH 차이일 수 있다.
- 프로젝트 .codex/config.toml은 비어 있다. 계획 논의 시 사용자 설정에서 여러 Unity MCP 섹션을 확인했고 현재 채팅의 MCP 도구 응답이 성공했다. 연결을 중복 등록하거나 기존 설정을 수정하지 않았다.
- CLI 버전과 로그인 상태는 미확인이다. MCP 연결 결과는 확인 시점의 상태이며 다음 작업에서 계속 연결되어 있다고 보장하지 않는다. 필요한 Editor 작업에서 대상·상태를 다시 확인한다.

팀 영향 관련 설명:
- 패키지 변경을 공유하면 팀원도 패키지를 내려받고 컴파일하게 된다. 내 Codex에 자동 연결되는 것은 아니다.
- 설치 자체가 씬·게임 코드를 자동 편집하는 작업은 아니지만, 버전/의존성/컴파일 영향은 검증이 필요하다.
- 개인 설치만 유지하려면 현재 폴더에서 해당 변경을 커밋하지 않고 관리하거나 개인 사본을 사용하는 선택지가 있다. 전자는 패키지 변경 혼합과 실수 커밋 관리가 필요하다.
- 사용자는 팀원에게 영향을 주지 않기를 원하며, 최종 패키지 공유 정책은 아직 확정하지 않았다. 임의로 커밋하거나 되돌리지 않는다.

공식 관련 자료:
- https://docs.unity.com/en-us/unity-cli/unity-pipeline/unity-pipeline-package
- https://docs.unity.com/en-us/unity-cli/replace-mcp-server-unity-cli
- https://docs.unity.com/en-us/unity-cli/unity-cli-reference

## 9. 이번 확인 시 Git 작업 상태와 안전한 재개

현재 git status --short에서 표시된 변경:

```text
 M Packages/manifest.json
 M Packages/packages-lock.json
```

이전 대화의 다른 시점에는 ProjectSettings 파일 두 개가 수정 상태였으나, 이번 확인 결과에는 나타나지 않았다. 이전 상태를 현재 사실처럼 사용하지 않는다.

다음 채팅 시작 시:
1. 이 HANDOFF.md와 현재 AGENTS.md를 읽는다.
2. git status와 실제 설정 파일 상태를 재확인한다. 민감할 수 있는 사용자 설정 전체를 불필요하게 출력하지 않는다.
3. 사용자의 새 메시지가 질문인지 명시적인 실행 요청인지 구분한다.
4. 하네스 내용 작성 요청이라면 관련 실제 파일을 확인하고 이미 확정한 사용자 정책을 유지한다. 필요한 미확정 선택만 확인하고 요청 범위의 파일을 작성한 뒤 하네스 검사 스크립트를 실행한다.
5. 빈 파일을 임의 규칙으로 채우거나, MCP/패키지 설치·설정·커밋을 자동으로 이어서 수행하지 않는다.

새 채팅에서 사용자가 보낼 수 있는 시작 문장:
“docs/ai/HANDOFF.md와 AGENTS.md를 읽고 현재 상태를 확인해줘. 이후 내가 요청하는 항목부터 함께 진행하자.”
