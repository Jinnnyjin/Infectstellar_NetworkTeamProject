# Infectstellar 프로젝트 안내

최초 구조 확인: 2026-10-05 (Asia/Seoul). 경로는 Unity 프로젝트 루트 기준이다.
관련 작업에서 실제 파일을 재확인하며 설명을 갱신한다. 아래 목록은 확인 범위의 안내이지 실행·게임 동작 검증 결과가 아니다.

## 개요와 환경

- Unity 팀 프로젝트의 개인용 안내 문서이다. 게임의 구체적인 기획, 담당 영역과 네트워크 설계는 미확정이다.
- Unity 프로젝트 루트: `Infectstellar/`. Git 저장소 루트는 그 부모 폴더이다.
- Unity 버전: `6000.3.6f1`. 근거: [ProjectVersion.txt](../../ProjectSettings/ProjectVersion.txt).
- 등록 패키지는 [manifest.json](../../Packages/manifest.json)과 [packages-lock.json](../../Packages/packages-lock.json)에서 확인한다. URP, Input System, Cinemachine, AI Navigation, Test Framework 등이 등록되어 있다. 등록 자체가 게임 시스템의 구현·사용을 증명하지는 않는다.
- `com.unity.pipeline`이 등록되어 있고 2026-10-05에는 현재 프로젝트의 MCP Editor 상태 조회가 성공했다. 조회 시점과 상세 결과·개인 패키지 변경 상태는 [HANDOFF.md](HANDOFF.md)에 둔다. CLI 설치 상태와 실제 게임 동작 검증은 이 결과와 구분한다.

## 주요 위치

| 경로 | 현재 확인된 내용 |
|---|---|
| `Assets/Scenes/SampleScene.unity` | 현재 확인된 유일한 씬. Main Camera, Directional Light, Global Volume 오브젝트가 있다. |
| `ProjectSettings/EditorBuildSettings.asset` | SampleScene 한 개가 활성 씬으로 등록되어 있다. |
| `Assets/InputSystem_Actions.inputactions` | Player·UI 액션 맵이 있다. Move·Jump·Attack 등의 액션 정의는 실제 이동·점프·공격 구현을 뜻하지 않는다. |
| `Assets/Settings/` | PC·Mobile 렌더 파이프라인/Renderer와 Volume Profile 등 렌더링 설정 자산이 있다. |
| `Assets/TutorialInfo/Scripts/Readme.cs` | 템플릿 안내를 담는 ScriptableObject이다. 게임 로직이 아니다. |
| `Assets/TutorialInfo/Scripts/Editor/ReadmeEditor.cs` | Readme 전용 Inspector와 템플릿 안내 표시 코드이다. |
| `Assets/Readme.asset` | URP Empty Template 안내 자산이다. |
| `Assets/KHJ/Script/`, `Assets/KHJ/Prefab/` | 폴더는 있으나 이번 검색에서 코드·프리팹 파일은 확인되지 않았다. 담당자를 폴더 이름으로 추정하지 않는다. |
| `Assets/Resources/` | DOTweenSettings.asset와 PhotonPrefabs 폴더가 있다. 이름만으로 DOTween·Photon 설치나 네트워크 구현을 확정하지 않는다. |
| `Assets/Import/`, `Assets/Plugins/` | 폴더는 있으나 이번 파일 검색에서 내용이 확인되지 않았다. |
| `Assets/TextMesh Pro/` | 폰트·머티리얼 등 텍스트 관련 자산이 있다. |

## 구현된 기능을 찾는 기준

- 최초 `Assets` 파일 검색에서는 C# 파일 두 개가 확인됐으며 모두 위 튜토리얼 코드이다. `.prefab`과 `.asmdef` 파일은 검색되지 않았다.
- 게임용 C# 시스템과 기능별 연결은 현재 확인되지 않았다. 패키지·입력 정의·준비된 폴더를 구현된 기능으로 기록하지 않는다.
- 기능 구현 이후에는 이 섹션에 **기능명, 주요 파일 위치, 역할, 연결된 코드·씬·프리팹**을 간결하게 기록한다. 함수 전체나 작업별 수치 변경 이력은 옮기지 않는다.
- 코드를 옮기거나 삭제한 경우 이전 위치를 정정한다. 문서와 실제 파일이 다르면 실제 구현을 기준으로 확인한 관련 설명만 갱신한다.

## 미확인 사항

- 구체적인 게임 목표·플레이 흐름·담당 영역과 팀 코드 컨벤션
- 네트워크 기술과 호스트/서버/클라이언트 역할
- 입력 액션을 소비하는 게임 코드, 기능별 프리팹과 씬 연결
- 실제 게임 실행·컴파일·테스트 결과와 CLI 설치 상태. MCP 연결은 Editor 작업 시 현재 상태를 다시 확인한다.

공통 작업 정책은 [AGENTS.md](../../AGENTS.md), 현재 작업 상태는 [HANDOFF.md](HANDOFF.md)에 둔다.
`COMMANDS.md`는 사용자 선택으로 비워둔다.
